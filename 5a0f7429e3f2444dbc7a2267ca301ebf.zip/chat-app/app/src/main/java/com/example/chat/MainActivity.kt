package com.example.chat

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val REQUEST_PERMISSIONS = 1001

    // 硬编码白名单：你和朋友的两个设备ID，把这两个值换成你俩的ANDROID_ID
    private val allowedDevices = setOf(
        "你的设备ID填这里",
        "你朋友的设备ID填这里"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 系统级防截屏、防录屏
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // 设备白名单校验
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        if (!allowedDevices.contains(androidId)) {
            Toast.makeText(this, "设备未授权，无法使用", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        requestPermissions()

        val webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // 禁止系统长按弹出菜单
            setSupportZoom(false)
            builtInZoomControls = false
        }
        // 彻底拦截长按事件，不弹系统复制菜单
        webView.setOnLongClickListener { true }
        webView.isLongClickable = false

        webView.addJavascriptInterface(JsBridge(this), "AndroidBridge")
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun requestPermissions() {
        val neededPermissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            neededPermissions.add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (neededPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, neededPermissions.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }
}
