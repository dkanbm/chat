package com.example.chat

import android.webkit.JavascriptInterface
import android.content.Context
import android.content.Intent

class JsBridge(private val context: Context) {

    @JavascriptInterface
    fun startModel(modelPath: String) {
        val serviceIntent = Intent(context, ModelService::class.java)
        serviceIntent.putExtra("modelPath", modelPath)
        context.startForegroundService(serviceIntent)
    }
}
