package com.example.chat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import java.io.File
import java.io.FileOutputStream

class ModelService : Service() {
    private var llamaProcess: Process? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val modelPath = intent?.getStringExtra("modelPath") ?: "/sdcard/qwen2.5-3b-instruct-q4_k_m.gguf"

        createNotificationChannel()
        val notification: Notification = Notification.Builder(this, "model_channel")
            .setContentTitle("本地AI运行中")
            .setContentText("模型已加载，随时可以对话")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()
        startForeground(1001, notification)

        // 先杀掉旧进程，避免端口冲突
        llamaProcess?.destroy()
        llamaProcess = null

        // 自动拷贝assets里的二进制到私有可执行目录
        val filesDir = filesDir.absolutePath
        val assetNames = arrayOf("llama-server", "libllama-server-impl.so", "libggml.so")
        for (name in assetNames) {
            val targetFile = File(filesDir, name)
            if (!targetFile.exists()) {
                assets.open(name).use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                targetFile.setExecutable(true)
            }
        }

        // 从私有可执行目录启动llama
        val processBuilder = ProcessBuilder(
            "$filesDir/llama-server",
            "-m", modelPath,
            "--host", "127.0.0.1",
            "--port", "8080"
        )
        processBuilder.redirectErrorStream(true)
        llamaProcess = processBuilder.start()

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "model_channel",
                "本地AI服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        llamaProcess?.destroy()
        llamaProcess = null
    }
}
